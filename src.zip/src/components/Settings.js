import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function Settings() {
  return (
    <View style={{flex:1, alignItems: 'center', justifyContent:'center',}}>
      <Text>Settings</Text>

    </View>
  )
}

const styles = StyleSheet.create({})